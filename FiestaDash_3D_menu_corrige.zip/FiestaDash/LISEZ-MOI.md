# Fiesta Dash : écran d'accueil pour autoradio Android (Ford Fiesta 1.6 TDCi)

Application Android (Kotlin) qui affiche ton interface : animation de démarrage Ford, tableau de bord,
codes défauts, entretien, historique, lancement de Think5 CarPlay et de la caméra 360.

## 1. Fabriquer l'APK (sur ton PC)
1. Installe **Android Studio** (gratuit) : https://developer.android.com/studio
2. `File > Open`, choisis ce dossier **FiestaDash**, attends la fin de la synchronisation (première fois : téléchargements).
3. Menu `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
4. L'APK se trouve dans `app/build/outputs/apk/debug/app-debug.apk`.
   (En ligne de commande : `./gradlew assembleDebug`.)

## 2. L'installer sur l'autoradio
- Copie `app-debug.apk` sur une clé USB, branche-la à l'autoradio, ouvre le fichier avec le gestionnaire de fichiers et installe-le
  (autorise « sources inconnues » si Android le demande).
- Ou, en USB / Wi-Fi débogage : `adb install app-debug.apk`.

## 3. Premier lancement : teste AVANT de la définir comme accueil
1. Ouvre **Fiesta Dash** depuis la liste des applications de l'autoradio.
2. Branche l'adaptateur OBD2 **ELM327 Bluetooth** sous le volant, mets le contact.
3. Appaire-le dans les réglages Bluetooth d'Android (code 1234 ou 0000).
4. Dans Fiesta Dash : **Paramètres > Adaptateur OBD2 > Connecter**.
   La connexion est ensuite automatique à chaque démarrage.
5. **Paramètres > Boutons d'applications** : si « Think5 CarPlay » ou « Caméra 360 » ne se lancent pas tout seuls,
   touche **Choisir** et sélectionne l'application voulue.
6. Quand tout te convient : **Paramètres > Définir cette interface comme écran d'accueil > Ouvrir**,
   choisis « Fiesta Dash » puis « Toujours ».

Pour revenir à l'ancien accueil : Réglages Android > Applications > Applications par défaut > Accueil.

## Ce qui fonctionne
- Animation de démarrage Ford (désactivable dans Paramètres).
- Jauges : vitesse, régime, température moteur et huile, tension, carburant, consommation (selon ce que répond ta voiture).
- Codes défauts moteur : lecture et effacement (avec confirmation), descriptions en français des codes courants (turbo, FAP, EGR…).
- Entretien (suivi par date) et historique : enregistrés dans l'autoradio.
- Liste de toutes tes applications et lancement en un toucher.

## Limites à connaître
- **Non testé sur ta voiture** : le code compile et la logique est vérifiée, mais les réponses de ton calculateur peuvent différer.
  Si une jauge affiche « -- », c'est que la voiture ne fournit pas cette mesure (fréquent pour la température d'huile et le carburant).
- Codes **ABS, airbag, carrosserie** : un ELM327 standard ne lit que le moteur. Il faut un adaptateur compatible Ford MS-CAN.
- Les petits boutons ronds à côté de la voiture (verrouillage, phares…) sont décoratifs : l'état des portes et des feux
  n'est pas lisible via la prise OBD2 standard.
- Radio, volume et commandes au volant restent gérés par l'application d'origine de l'autoradio (bouton Applications).
- Efface un code défaut seulement si tu as compris la panne : un vrai défaut réapparaîtra.

## Fichiers utiles
- `app/src/main/assets/index.html`, `app.js` : l'interface (modifiable avec n'importe quel éditeur de texte).
- `app/src/main/assets/fiesta.glb` : modèle 3D source de la Fiesta.
- `app/src/main/assets/car360/` : 36 vues locales du modèle, utilisées pour la rotation tactile hors ligne.
- `app/src/main/java/fr/fiestadash/` : `MainActivity.kt` (écran), `Bridge.kt` (applications), `ObdManager.kt` (OBD2).

## Modèle de voiture et rotation
La voiture du centre utilise les 36 vues locales calculées depuis ton fichier `fiesta.glb` : elle a une apparence 3D et tourne au doigt, puis lentement au repos. Tout fonctionne hors ligne. Si une image d'angle est introuvable sur l'autoradio, l'application affiche automatiquement `car.png` au lieu de laisser la zone vide. Ce rendu 360° est pré-calculé ; ce n'est pas encore un moteur 3D temps réel manipulant les pièces du GLB.


## Correctifs affichage 3D (version 2)
- Modèle GLB corrigé : suppression de l'échelle erronée 0,01 (dimensions du véhicule ~4,0 x 2,0 x 1,7 m).
- Les 36 vues de rotation ont été agrandies et recentrées de façon cohérente.
- Zone d'affichage du véhicule agrandie.
- Rotation automatique réglée à 100 ms par image et démarrée après le préchargement des vues.
- Les fichiers Kotlin, la communication OBD2/CANBUS et les écrans de diagnostic n'ont pas été modifiés.
