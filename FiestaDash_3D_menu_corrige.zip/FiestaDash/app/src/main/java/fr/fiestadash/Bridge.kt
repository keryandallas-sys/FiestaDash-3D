package fr.fiestadash

import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.provider.Settings
import android.util.Base64
import android.webkit.JavascriptInterface
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

/**
 * Fonctions appelables depuis la page web (objet JavaScript "Android").
 * Tout ce qui revient vers la page passe par MainActivity.js().
 */
class Bridge(private val act: MainActivity) {

    private val pm = act.packageManager
    private var obd: ObdManager? = null
    @Volatile private var appsCache: String? = null

    // ---------- Applications ----------

    private fun launchables(): List<ResolveInfo> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0).filter { it.activityInfo.packageName != act.packageName }
    }

    private fun iconData(d: Drawable): String {
        val size = 96
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, size, size)
        d.draw(Canvas(bmp))
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
        return "data:image/png;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    @JavascriptInterface
    fun listApps(): String {
        appsCache?.let { return it }
        val arr = JSONArray()
        launchables()
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
            .distinctBy { it.activityInfo.packageName }
            .forEach { ri ->
                try {
                    arr.put(JSONObject()
                        .put("label", ri.loadLabel(pm).toString())
                        .put("pkg", ri.activityInfo.packageName)
                        .put("icon", iconData(ri.loadIcon(pm))))
                } catch (_: Exception) { /* icône illisible : on ignore cette appli */ }
            }
        return arr.toString().also { appsCache = it }
    }

    private fun start(pkg: String): Boolean {
        val i = pm.getLaunchIntentForPackage(pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        act.runOnUiThread { try { act.startActivity(i) } catch (_: Exception) { } }
        return true
    }

    @JavascriptInterface
    fun launchPackage(pkg: String): Boolean = start(pkg)

    /** Cherche une application dont le nom ou le paquet contient un des mots-clés ; renvoie son nom ou "". */
    @JavascriptInterface
    fun launchByKeywords(keywordsJson: String): String {
        val kw = try {
            JSONArray(keywordsJson).let { a -> (0 until a.length()).map { a.getString(it).lowercase() } }
        } catch (_: Exception) { emptyList() }
        for (ri in launchables()) {
            val label = ri.loadLabel(pm).toString()
            val hay = (label + " " + ri.activityInfo.packageName).lowercase()
            if (kw.any { hay.contains(it) } && start(ri.activityInfo.packageName)) return label
        }
        return ""
    }

    // ---------- Réglages Android ----------

    @JavascriptInterface
    fun openHomeSettings() = act.runOnUiThread {
        try {
            act.startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            // Repli : lancer le sélecteur d'écran d'accueil
            try {
                act.startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED))
            } catch (_: Exception) { }
        }
    }

    @JavascriptInterface
    fun openSettings() = act.runOnUiThread {
        try { act.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { }
    }

    @JavascriptInterface
    fun openBluetoothSettings() = act.runOnUiThread {
        try { act.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { }
    }

    // ---------- OBD2 ----------

    @JavascriptInterface
    fun obdDevices(): String {
        val arr = JSONArray()
        try {
            BluetoothAdapter.getDefaultAdapter()?.bondedDevices?.forEach {
                arr.put(JSONObject().put("name", it.name ?: "Appareil").put("address", it.address))
            }
        } catch (_: SecurityException) { /* permission Bluetooth refusée */ }
        return arr.toString()
    }

    @JavascriptInterface
    fun obdConnect(address: String) {
        obd?.stop()
        obd = ObdManager(address) { fn, o -> act.js(fn, o.toString()) }.also { it.start() }
    }

    @JavascriptInterface
    fun obdDisconnect() {
        obd?.stop()
        obd = null
        act.js("onObdStatus", JSONObject().put("state", "off").toString())
    }

    @JavascriptInterface
    fun readDtc() {
        val o = obd
        if (o == null) act.js("onDtc", JSONObject().put("ok", false).put("error", "Adaptateur non connecté").toString())
        else o.readDtc()
    }

    @JavascriptInterface
    fun clearDtc() {
        val o = obd
        if (o == null) act.js("onDtcCleared", JSONObject().put("ok", false).toString())
        else o.clearDtc()
    }

    fun shutdown() {
        obd?.stop()
        obd = null
    }
}
