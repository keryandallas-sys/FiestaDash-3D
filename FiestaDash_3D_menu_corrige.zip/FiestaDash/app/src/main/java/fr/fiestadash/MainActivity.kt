package fr.fiestadash

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import org.json.JSONObject

/**
 * Écran d'accueil de la Fiesta : une WebView plein écran qui affiche l'interface
 * (animation de démarrage Ford + tableau de bord) et dialogue avec Android
 * via l'objet JavaScript "Android" (voir Bridge).
 */
class MainActivity : Activity() {

    private val BT_CONNECT = "android.permission.BLUETOOTH_CONNECT"   // Android 12+
    private lateinit var web: WebView
    private lateinit var bridge: Bridge

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true          // sauvegarde des réglages, de l'entretien et de l'historique
            mediaPlaybackRequiresUserGesture = false
        }
        web.webChromeClient = WebChromeClient()

        bridge = Bridge(this)
        web.addJavascriptInterface(bridge, "Android")
        web.loadUrl("file:///android_asset/index.html")

        hideSystemUi()
        requestBluetoothPermission()
    }

    /** Appelle une fonction JavaScript de la page avec un texte JSON en paramètre. */
    fun js(function: String, json: String) {
        val arg = JSONObject.quote(json)
        web.post { web.evaluateJavascript("window.$function&&window.$function($arg)", null) }
    }

    private fun hideSystemUi() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
    }

    private fun requestBluetoothPermission() {
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(BT_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(BT_CONNECT), 1)
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    /** Appui sur Home alors que l'application tourne déjà : retour à l'accueil. */
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent?.hasCategory(Intent.CATEGORY_HOME) == true) js("onHome", "{}")
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        // La page décide : fermer une fenêtre, revenir à l'accueil… Rien n'est quitté par erreur.
        js("onBack", "{}")
    }

    override fun onDestroy() {
        bridge.shutdown()
        web.removeJavascriptInterface("Android")
        super.onDestroy()
    }
}
