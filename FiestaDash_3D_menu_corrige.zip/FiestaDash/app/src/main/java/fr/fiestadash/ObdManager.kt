package fr.fiestadash

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothSocket
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

/**
 * Dialogue avec un adaptateur ELM327 Bluetooth (profil série SPP).
 * - Une connexion, puis une boucle qui lit régime, vitesse, températures, tension, carburant.
 * - Lecture / effacement des codes défauts moteur (modes OBD 03 et 04).
 * Toutes les valeurs absentes (le véhicule ne répond pas à ce PID) sont simplement omises :
 * l'interface affiche alors "--".
 */
class ObdManager(
    private val address: String,
    private val emit: (String, JSONObject) -> Unit
) {
    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val lock = Any()

    @Volatile private var running = false
    @Volatile private var stoppedByUser = false
    private var socket: BluetoothSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null
    private var thread: Thread? = null
    private var isCan = true
    private var consAvg: Double? = null

    fun start() {
        running = true
        thread = Thread({ run() }, "obd-poll").also { it.isDaemon = true; it.start() }
    }

    fun stop() {
        stoppedByUser = true
        running = false
        try { socket?.close() } catch (_: IOException) { }
        thread?.interrupt()
    }

    // ---------- Connexion + boucle de lecture ----------

    private fun run() {
        emit("onObdStatus", JSONObject().put("state", "connecting"))
        try {
            connect()
            val protocol = initElm()
            emit("onObdStatus", JSONObject().put("state", "connected").put("protocol", protocol)
                .put("name", try { socket?.remoteDevice?.name } catch (_: SecurityException) { null } ?: "ELM327"))
            poll()
        } catch (e: Exception) {
            if (!stoppedByUser) {
                emit("onObdStatus", JSONObject().put("state", "off").put("error", e.message ?: "erreur inconnue"))
            }
        } finally {
            running = false
            try { socket?.close() } catch (_: IOException) { }
        }
    }

    private fun connect() {
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: throw IOException("Bluetooth indisponible")
        if (!adapter.isEnabled) throw IOException("Bluetooth désactivé")
        val dev = try { adapter.getRemoteDevice(address) } catch (_: IllegalArgumentException) { throw IOException("Adresse invalide") }
        try { adapter.cancelDiscovery() } catch (_: SecurityException) { }

        var s: BluetoothSocket? = null
        try {
            s = dev.createRfcommSocketToServiceRecord(sppUuid)
            s.connect()
        } catch (_: Exception) {
            // Certains adaptateurs n'acceptent que le canal 1 : méthode de repli
            try { s?.close() } catch (_: IOException) { }
            try {
                val m = dev.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                s = m.invoke(dev, 1) as BluetoothSocket
                s.connect()
            } catch (e: Exception) {
                throw IOException("Connexion impossible (adaptateur allumé et à portée ?)")
            }
        }
        socket = s
        input = s!!.inputStream
        output = s.outputStream
    }

    private fun initElm(): String {
        send("ATZ", 3000)
        send("ATE0"); send("ATL0"); send("ATS0"); send("ATH0"); send("ATSP0")
        val probe = send("0100", 9000)
        if (!probe.replace(" ", "").contains("4100")) {
            throw IOException("Le véhicule ne répond pas (contact mis ?)")
        }
        val num = send("ATDPN").trim().uppercase().removePrefix("A")
        isCan = num.isNotEmpty() && (num[0] in '6'..'9' || num[0] in 'A'..'C')
        return send("ATDP").trim().removePrefix("AUTO, ").ifEmpty { "OBD2" }
    }

    private fun poll() {
        var oil: Int? = null; var volt: Double? = null; var fuel: Int? = null; var rate: Double? = null
        var n = 0
        while (running) {
            val rpm = pid("01", "0C")?.let { (it[0] * 256 + it[1]) / 4 }
            val speed = pid("01", "0D")?.let { it[0] }
            val cool = pid("01", "05")?.let { it[0] - 40 }
            when (n % 4) {
                0 -> oil = pid("01", "5C")?.let { it[0] - 40 } ?: oil
                1 -> volt = (pid("01", "42")?.let { (it[0] * 256 + it[1]) / 1000.0 } ?: readRv()) ?: volt
                2 -> fuel = pid("01", "2F")?.let { it[0] * 100 / 255 } ?: fuel
                3 -> rate = pid("01", "5E")?.let { (it[0] * 256 + it[1]) / 20.0 } ?: rate
            }
            n++
            if (speed != null && speed >= 10 && rate != null) {
                val inst = rate / speed * 100.0
                consAvg = consAvg?.let { it * 0.98 + inst * 0.02 } ?: inst
            }
            val o = JSONObject()
            rpm?.let { o.put("rpm", it) }
            speed?.let { o.put("speed", it) }
            cool?.let { o.put("coolant", it) }
            oil?.let { o.put("oil", it) }
            volt?.let { o.put("volt", Math.round(it * 10) / 10.0) }
            fuel?.let { o.put("fuel", it) }
            rate?.let { o.put("fuelRate", Math.round(it * 10) / 10.0) }
            consAvg?.let { o.put("cons", Math.round(it * 10) / 10.0) }
            emit("onObdData", o)
            try { Thread.sleep(120) } catch (_: InterruptedException) { return }
        }
    }

    // ---------- Codes défauts ----------

    fun readDtc() {
        Thread({
            val r = JSONObject()
            try {
                val mil = pid("01", "01")?.let { it[0] and 0x80 != 0 } ?: false
                val resp = send("03", 6000)
                if (resp.uppercase().contains("UNABLE") || resp.contains("ERROR")) throw IOException("Pas de réponse du calculateur")
                r.put("ok", true).put("mil", mil).put("codes", JSONArray(parseDtc(resp)))
            } catch (e: Exception) {
                r.put("ok", false).put("error", e.message ?: "erreur")
            }
            emit("onDtc", r)
        }, "obd-dtc").start()
    }

    fun clearDtc() {
        Thread({
            val r = JSONObject()
            try {
                val resp = send("04", 6000)
                r.put("ok", resp.replace(" ", "").contains("44"))
            } catch (e: Exception) {
                r.put("ok", false)
            }
            emit("onDtcCleared", r)
        }, "obd-dtc-clear").start()
    }

    /** Transforme la réponse du mode 03 en codes lisibles (P0299, P2002…). Meilleur effort : à valider sur la voiture. */
    private fun parseDtc(resp: String): List<String> {
        val lines = resp.split("\n").map { it.trim().uppercase().replace(" ", "") }.filter { it.isNotEmpty() }
        val frames = ArrayList<String>()
        var multi = false
        val chunks = ArrayList<String>()
        for (l in lines) {
            if (l == "NODATA" || l.startsWith("UNABLE") || l == "?" ) continue
            if (l.length >= 2 && l[1] == ':') { multi = true; chunks.add(l.substring(2)); continue }
            if (l.length == 3 && l.all { it in '0'..'9' || it in 'A'..'F' }) continue   // en-tête "nombre d'octets"
            frames.add(l)
        }
        if (multi) frames.add(chunks.joinToString(""))

        val codes = LinkedHashSet<String>()
        for (f in frames) {
            val i = f.indexOf("43")
            if (i < 0) continue
            var data = f.substring(i + 2)
            if (isCan && data.length >= 2) data = data.substring(2)   // sur CAN, 1er octet = nombre de codes
            var p = 0
            while (p + 4 <= data.length) {
                val hex = data.substring(p, p + 4)
                p += 4
                if (hex == "0000") continue
                val b1 = hex.substring(0, 2).toInt(16)
                val type = "PCBU"[(b1 shr 6) and 3]
                codes.add("" + type + ((b1 shr 4) and 3) + Integer.toHexString(b1 and 0xF).uppercase() + hex.substring(2).uppercase())
            }
        }
        return codes.toList()
    }

    // ---------- Bas niveau ----------

    private fun pid(mode: String, pid: String): IntArray? {
        val resp = send(mode + pid).uppercase().replace(" ", "")
        val tag = "4" + mode.substring(1) + pid
        for (line in resp.split("\n")) {
            val i = line.indexOf(tag)
            if (i >= 0) {
                val hex = line.substring(i + tag.length)
                if (hex.length < 2) continue
                val out = IntArray(hex.length / 2) { hex.substring(it * 2, it * 2 + 2).toIntOrNull(16) ?: 0 }
                return out
            }
        }
        return null
    }

    /** Tension lue directement par l'adaptateur (ATRV) quand le PID 0142 n'existe pas. */
    private fun readRv(): Double? =
        send("ATRV").uppercase().replace("V", "").trim().toDoubleOrNull()

    private fun send(cmd: String, timeoutMs: Long = 2000): String = synchronized(lock) {
        val out = output ?: throw IOException("Connexion fermée")
        val inp = input ?: throw IOException("Connexion fermée")
        while (inp.available() > 0) inp.read()        // vide les restes
        out.write((cmd + "\r").toByteArray())
        out.flush()
        val sb = StringBuilder()
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            if (inp.available() > 0) {
                val c = inp.read()
                if (c < 0) throw IOException("Connexion fermée")
                if (c.toChar() == '>') break
                sb.append(c.toChar())
            } else {
                try { Thread.sleep(8) } catch (_: InterruptedException) { throw IOException("Arrêt") }
            }
        }
        sb.toString().replace("\r", "\n").split("\n").map { it.trim() }
            .filter { it.isNotEmpty() && !it.startsWith("SEARCHING") && !it.equals(cmd, true) }
            .joinToString("\n")
    }
}
