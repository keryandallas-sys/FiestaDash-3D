(function(){
'use strict';
const $=s=>document.querySelector(s), $$=s=>Array.prototype.slice.call(document.querySelectorAll(s));
const J=s=>{try{return JSON.parse(s)}catch(e){return null}};
const esc=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const store={
  get(k,d){try{const v=localStorage.getItem('fd_'+k);return v==null?d:JSON.parse(v)}catch(e){return d}},
  set(k,v){try{localStorage.setItem('fd_'+k,JSON.stringify(v))}catch(e){}}
};
const KW={carplay:['carplay','think5','think'],camera:['360','camera','caméra','avm','surround']};
const SLOT_NAME={carplay:'Think5 CarPlay',camera:'Caméra 360'};
const fdate=t=>new Date(t).toLocaleString('fr-FR',{day:'numeric',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'});
const fday=t=>new Date(t).toLocaleDateString('fr-FR',{day:'numeric',month:'long',year:'numeric'});

/* ===== Pont de démo (aperçu dans un navigateur, sans l'application Android) ===== */
function makeMock(){
  const ico=(c,l)=>'data:image/svg+xml;utf8,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="96" height="96"><rect width="96" height="96" rx="20" fill="'+c+'"/><text x="48" y="64" font-size="46" text-anchor="middle" fill="#fff" font-family="Arial">'+l+'</text></svg>');
  const apps=[['Think5 CarPlay','#1d6fe0','C'],['Caméra 360','#2b8a5a','◎'],['Radio','#c2410c','R'],['Bluetooth','#2563eb','B'],['Fichiers','#8a6d1d','F'],['Galerie','#a21caf','G'],['Réglages','#4b5563','⚙'],['Chrome','#d93025','C'],['YouTube','#c4302b','▶'],['Calculatrice','#0f766e','='],['Horloge','#334155','⏱'],['Météo','#0284c7','☁'],['Contacts','#0e7490','☺'],['Téléphone','#15803d','✆'],['Messages','#4338ca','✉'],['Musique','#be185d','♪'],['Enregistreur','#b91c1c','●'],['Navigateur','#475569','◉']]
    .map((a,i)=>({label:a[0],pkg:'demo.app'+i,icon:ico(a[1],a[2])}));
  let timer=null, n=0;
  const emit=(fn,o)=>window[fn]&&window[fn](JSON.stringify(o));
  function start(){clearInterval(timer);timer=setInterval(()=>{n++;emit('onObdData',{speed:0,rpm:748+Math.round(Math.sin(n/3)*14),coolant:83,oil:76,volt:+(14.25+Math.sin(n/5)*.1).toFixed(2),fuel:58,fuelRate:1.1,cons:5.6})},700)}
  return {
    isMock:true,
    listApps:()=>JSON.stringify(apps),
    launchPackage:()=>true,
    launchByKeywords:k=>'Démo',
    obdDevices:()=>JSON.stringify([{name:'OBDII',address:'00:1D:A5:68:98:8B'},{name:'vLinker MC',address:'AA:BB:CC:DD:EE:FF'}]),
    obdConnect:a=>{emit('onObdStatus',{state:'connecting'});setTimeout(()=>{emit('onObdStatus',{state:'connected',name:'OBDII',protocol:'ISO 15765-4 CAN',demo:true});start()},900)},
    obdDisconnect:()=>{clearInterval(timer);emit('onObdStatus',{state:'off'})},
    readDtc:()=>setTimeout(()=>emit('onDtc',{ok:true,codes:['P0299','P2002'],mil:true}),700),
    clearDtc:()=>setTimeout(()=>emit('onDtcCleared',{ok:true}),700),
    openHomeSettings:()=>{},openSettings:()=>{},openBluetoothSettings:()=>{}
  };
}
const native=!!window.Android;
const B=window.Android||makeMock();

/* ===== Éléments communs ===== */
const stage=$('#stage');
stage.insertAdjacentHTML('beforeend','<div id="toast"></div><div id="modal"><div class="box"><p></p><div class="btns"><div class="btn cancel">Annuler</div><div class="btn danger ok">OK</div></div></div></div>');
let tt;
function toast(m){const e=$('#toast');e.textContent=m;e.classList.add('show');clearTimeout(tt);tt=setTimeout(()=>e.classList.remove('show'),2800)}
function ask(msg,ok){return new Promise(res=>{
  const m=$('#modal');m.querySelector('p').textContent=msg;m.querySelector('.ok').textContent=ok||'OK';m.classList.add('show');
  const done=v=>{m.classList.remove('show');res(v)};
  m.querySelector('.ok').onclick=()=>done(true);m.querySelector('.cancel').onclick=()=>done(false);
})}

const st={obd:{state:'off'},data:{},apps:null,pick:null,dtc:store.get('dtc',null),view:'home'};
function log(txt){const h=store.get('hist',[]);h.unshift({t:Date.now(),txt});store.set('hist',h.slice(0,200))}

/* ===== Données en direct ===== */
const fmt=(v,d)=>(v==null||isNaN(v))?'--':Number(v).toFixed(d||0);
const setT=(id,t)=>{const e=document.getElementById(id);if(e)e.textContent=t};
const pct=(v,a,b)=>v==null?0:Math.max(0,Math.min(100,(v-a)/(b-a)*100));
function updateGauges(d){
  d=d||{};st.data=d;
  setT('vSpeed',fmt(d.speed));setT('vRpm',fmt(d.rpm));setT('vCool',fmt(d.coolant));setT('vOil',fmt(d.oil));
  setT('vVolt',fmt(d.volt,1));setT('volt',d.volt==null?'-- V':fmt(d.volt,1)+' V');
  const G=$$('#gauges .g');
  G[5].querySelector('.v span').textContent=fmt(d.fuel);G[6].querySelector('.v span').textContent=fmt(d.cons,1);
  const L=$$('#gauges .lvl i');
  L[0].style.width=pct(d.coolant,40,120)+'%';L[1].style.width=pct(d.oil,40,130)+'%';L[2].style.width=(d.fuel==null?0:pct(d.fuel,0,100))+'%';
  setT('lv-speed',fmt(d.speed));setT('lv-rpm',fmt(d.rpm));setT('lv-cool',fmt(d.coolant));setT('lv-oil',fmt(d.oil));
  setT('lv-volt',fmt(d.volt,1));setT('lv-fuel',fmt(d.fuel));setT('lv-cons',fmt(d.cons,1));setT('lv-fuelrate',fmt(d.fuelRate,1));
  const b=(id,p)=>{const e=document.getElementById(id);if(e)e.style.width=p+'%'};
  b('lb-rpm',pct(d.rpm,0,5000));b('lb-cool',pct(d.coolant,40,120));b('lb-oil',pct(d.oil,40,130));b('lb-fuel',d.fuel==null?0:pct(d.fuel,0,100));
}
function updateConn(){
  const o=st.obd,dot=$('#connDot');
  dot.className=o.state==='connected'?'':(o.state==='connecting'?'busy':'off');
  let t;
  if(o.state==='connected')t=o.demo?'Mode démo (données simulées)':'Véhicule connecté (OBD2'+(o.protocol?' · '+o.protocol:'')+')';
  else if(o.state==='connecting')t='Connexion à l’adaptateur…';
  else t=o.error?('Adaptateur non connecté : '+o.error):'Adaptateur OBD2 non connecté';
  $('#connTxt').textContent=t;$('#liveSub').textContent=t;
  if(o.state!=='connected')updateGauges({});
}
function updateBadge(){
  const b=$('.badge'),n=st.dtc?st.dtc.codes.length:0;
  b.style.display=n?'flex':'none';b.textContent=n;
}
window.onObdStatus=s=>{
  const o=J(s)||{state:'off'},prev=st.obd.state;st.obd=o;updateConn();
  if(o.state==='connected'&&prev!=='connected')log('Adaptateur connecté'+(o.name?' : '+o.name:''));
  if(o.state==='off'&&prev==='connected')log('Adaptateur déconnecté');
  if(st.view==='settings')renderSettings();
  if(st.view==='vehicle')renderVehicle();
};
window.onObdData=s=>{const d=J(s);if(d){updateGauges(d);if(st.view==='vehicle')renderVehicle()}};
window.onDtc=s=>{
  const r=J(s)||{ok:false};
  if(!r.ok){toast('Lecture impossible : '+(r.error||'pas de réponse'));return}
  st.dtc={t:Date.now(),codes:r.codes||[],mil:!!r.mil};store.set('dtc',st.dtc);
  log(st.dtc.codes.length?'Codes lus : '+st.dtc.codes.join(', '):'Lecture des codes : aucun défaut');
  renderDtc();updateBadge();
};
window.onDtcCleared=s=>{
  const r=J(s)||{};
  if(r.ok){st.dtc={t:Date.now(),codes:[],mil:false};store.set('dtc',st.dtc);log('Codes défauts effacés');toast('Codes effacés');renderDtc();updateBadge()}
  else toast('Effacement impossible');
};

/* ===== Codes défauts ===== */
const DTC={
  P0087:'Pression du rail de carburant trop basse',P0088:'Pression du rail de carburant trop élevée',P0089:'Régulateur de pression carburant',
  P0100:'Débitmètre d’air (MAF) : circuit',P0101:'Débitmètre d’air : performance',P0102:'Débitmètre d’air : signal trop bas',P0103:'Débitmètre d’air : signal trop haut',
  P0105:'Capteur de pression d’admission (MAP)',P0110:'Capteur température d’air d’admission',P0115:'Capteur température liquide de refroidissement',
  P0116:'Température liquide : plage/performance',P0117:'Température liquide : signal trop bas',P0118:'Température liquide : signal trop haut',
  P0120:'Capteur position pédale/papillon',P0190:'Capteur pression rail : circuit',P0191:'Capteur pression rail : plage/performance',
  P0201:'Injecteur cylindre 1 : circuit',P0202:'Injecteur cylindre 2 : circuit',P0203:'Injecteur cylindre 3 : circuit',P0204:'Injecteur cylindre 4 : circuit',
  P0234:'Suralimentation turbo trop élevée',P0235:'Capteur pression turbo : circuit',P0236:'Capteur pression turbo : plage/performance',
  P0237:'Capteur pression turbo : signal bas',P0238:'Capteur pression turbo : signal haut',P0299:'Suralimentation turbo insuffisante',
  P0335:'Capteur de vilebrequin : circuit',P0340:'Capteur d’arbre à cames : circuit',P0380:'Bougies de préchauffage : circuit',P0381:'Témoin de préchauffage : circuit',
  P0400:'Recirculation des gaz (EGR) : débit',P0401:'EGR : débit insuffisant',P0402:'EGR : débit excessif',P0403:'EGR : circuit électrovanne',
  P0404:'EGR : plage/performance',P0405:'EGR : capteur de position bas',P0406:'EGR : capteur de position haut',P0409:'EGR : capteur de position',
  P0420:'Efficacité du catalyseur trop faible',P0470:'Capteur pression échappement : circuit',P0471:'Capteur pression échappement : plage',
  P0472:'Capteur pression échappement : signal bas',P0473:'Capteur pression échappement : signal haut',P0480:'Ventilateur de refroidissement : circuit',
  P0500:'Capteur de vitesse du véhicule',P0562:'Tension du système trop basse',P0563:'Tension du système trop élevée',
  P0605:'Calculateur moteur : erreur mémoire',P0606:'Calculateur moteur : défaut processeur',
  P2002:'Filtre à particules (FAP) : efficacité trop faible',P2263:'Turbo : performance du système',P2452:'FAP : circuit capteur de pression différentielle',
  P2453:'FAP : pression différentielle plage/performance',P2454:'FAP : pression différentielle signal bas',P2455:'FAP : pression différentielle signal haut',
  P2458:'FAP : durée du cycle de régénération',U0100:'Perte de communication avec le calculateur moteur',U0121:'Perte de communication avec l’ABS'
};
function renderDtc(){
  const d=st.dtc,list=$('#dtcList'),sub=$('#dtcSub');
  if(!d){sub.textContent='Appuie sur « Lire les codes » (contact mis).';list.innerHTML='<div class="empty">Aucune lecture effectuée.</div>';return}
  sub.textContent='Dernière lecture : '+fdate(d.t)+(d.mil?' · Voyant moteur allumé':'');
  if(!d.codes.length){list.innerHTML='<div class="empty">✔ Aucun code défaut</div>';return}
  list.innerHTML=d.codes.map(c=>'<div class="card row"><div class="code">'+esc(c)+'</div><div class="grow">'+esc(DTC[c]||'Description non disponible : recherche ce code pour plus de détails.')+'</div></div>').join('');
}
$('#dtcRead').onclick=()=>{
  if(st.obd.state!=='connected'){toast('Connecte d’abord l’adaptateur dans Paramètres');return}
  toast('Lecture en cours…');B.readDtc();
};
$('#dtcClear').onclick=async()=>{
  if(st.obd.state!=='connected'){toast('Connecte d’abord l’adaptateur dans Paramètres');return}
  if(await ask('Effacer tous les codes défauts ? Le voyant moteur s’éteindra, mais un défaut réel réapparaîtra.','Effacer'))B.clearDtc();
};

/* ===== Entretien ===== */
const MAINT_DEF=[['Vidange + filtre à huile',12],['Filtre à air',24],['Filtre à gasoil',24],['Filtre d’habitacle',12],['Liquide de frein',24],['Courroie de distribution',60],['Contrôle technique',24]];
function maint(){let m=store.get('maint',null);if(!m){m=MAINT_DEF.map(x=>({n:x[0],months:x[1],last:null}));store.set('maint',m)}return m}
function renderMaint(){
  const m=maint(),now=Date.now();
  $('#maintList').innerHTML=m.map((it,i)=>{
    let pill='<span class="pill">À renseigner</span>',sub='Tous les '+it.months+' mois';
    if(it.last){const nx=new Date(it.last);nx.setMonth(nx.getMonth()+it.months);const days=(nx-now)/864e5;
      sub='Dernier : '+fday(it.last)+' · prochain : '+fday(nx);
      pill=days<0?'<span class="pill late">En retard</span>':days<30?'<span class="pill soon">Bientôt</span>':'<span class="pill ok">OK</span>'}
    return '<div class="card row"><div class="grow">'+esc(it.n)+'<div class="small">'+esc(sub)+'</div></div>'+pill+'<div class="btn" data-m="'+i+'">Fait</div></div>';
  }).join('');
}
$('#maintList').onclick=e=>{
  const b=e.target.closest('[data-m]');if(!b)return;
  const m=maint(),it=m[+b.dataset.m];it.last=Date.now();store.set('maint',m);log('Entretien effectué : '+it.n);renderMaint();toast('Enregistré : '+it.n);
};

/* ===== Historique ===== */
function renderHist(){
  const h=store.get('hist',[]);
  $('#histList').innerHTML=h.length?h.map(x=>'<div class="card row"><div class="grow">'+esc(x.txt)+'</div><div class="small" style="margin:0">'+esc(fdate(x.t))+'</div></div>').join(''):'<div class="empty">Aucun événement pour le moment.</div>';
}
$('#histClear').onclick=async()=>{if(await ask('Vider tout l’historique ?','Vider')){store.set('hist',[]);renderHist()}};

/* ===== Véhicule ===== */
function renderVehicle(){
  const o=st.obd,d=st.data;
  const rows=[['Modèle','Ford Fiesta 1.6 TDCi'],['Adaptateur OBD2',o.state==='connected'?(o.name||'Connecté'):(o.state==='connecting'?'Connexion…':'Non connecté')],
    ['Protocole',o.protocol||'--'],['Tension batterie',d.volt==null?'--':fmt(d.volt,1)+' V'],['Dernière lecture des codes',st.dtc?fdate(st.dtc.t):'--'],['Version de l’application','1.0']];
  $('#vehInfo').innerHTML=rows.map(r=>'<div class="card row"><div class="grow" style="color:var(--muted)">'+r[0]+'</div><div>'+esc(r[1])+'</div></div>').join('');
}

/* ===== Applications ===== */
function loadApps(){if(!st.apps)st.apps=J(B.listApps())||[];return st.apps}
function renderApps(){
  const apps=loadApps(),pick=st.pick;
  $('#appsTitle').textContent=pick?'Choisir : '+SLOT_NAME[pick]:'Applications';
  $('#appsSub').textContent=pick?'Touche l’application à associer à ce bouton.':'Touche une application pour l’ouvrir.';
  $('#appsCancel').style.display=pick?'inline-flex':'none';
  $('#appsGrid').innerHTML=apps.length?apps.map((a,i)=>'<div class="app-tile" data-i="'+i+'"><img alt="" src="'+(a.icon||'')+'"><span>'+esc(a.label)+'</span></div>').join(''):'<div class="empty" style="grid-column:1/-1">Aucune application trouvée.</div>';
}
$('#appsGrid').onclick=e=>{
  const t=e.target.closest('.app-tile');if(!t)return;
  const a=st.apps[+t.dataset.i];
  if(st.pick){store.set('slot_'+st.pick,a.pkg);store.set('slotname_'+st.pick,a.label);toast(SLOT_NAME[st.pick]+' → '+a.label);st.pick=null;show('settings')}
  else if(B.launchPackage(a.pkg)===false)toast('Impossible d’ouvrir cette application');
};
$('#appsCancel').onclick=()=>{st.pick=null;show('settings')};
function launchSlot(slot){
  const pkg=store.get('slot_'+slot,null);
  if(pkg){if(B.launchPackage(pkg)===false)toast('Impossible d’ouvrir '+SLOT_NAME[slot]);return}
  const lab=B.launchByKeywords(JSON.stringify(KW[slot]));
  if(!lab)toast(SLOT_NAME[slot]+' introuvable : choisis l’application dans Paramètres');
}

/* ===== Paramètres ===== */
function renderSettings(){
  const devs=J(B.obdDevices())||[],addr=store.get('obdAddr',null);
  const slotTxt=s=>store.get('slotname_'+s,null)||'Détection automatique';
  let h='<div class="sec">Adaptateur OBD2 (Bluetooth)</div>';
  if(!devs.length)h+='<div class="card row"><div class="grow">Aucun appareil appairé.<div class="small">Appaire l’adaptateur ELM327 dans les réglages Bluetooth d’Android, puis reviens ici.</div></div><div class="btn" data-act="bt">Réglages Bluetooth</div></div>';
  devs.forEach((d,i)=>{
    const sel=addr===d.address,con=sel&&st.obd.state==='connected';
    h+='<div class="card row'+(sel?' sel':'')+'"><div class="grow">'+esc(d.name||'Appareil')+'<div class="small">'+esc(d.address)+(con?' · connecté':'')+'</div></div><div class="btn" data-act="dev" data-i="'+i+'">'+(con?'Reconnecter':'Connecter')+'</div></div>';
  });
  h+='<div class="card row"><div class="grow">Se connecter automatiquement au démarrage</div><div class="toggle'+(store.get('autoConnect',true)?' on':'')+'" data-act="auto"></div></div>';
  h+='<div class="card row"><div class="grow">Adaptateur</div><div class="btn" data-act="disc">Déconnecter</div><div class="btn" data-act="refresh">Actualiser</div></div>';
  h+='<div class="sec" style="margin-top:20px">Boutons d’applications</div>';
  ['carplay','camera'].forEach(s=>{
    h+='<div class="card row"><div class="grow">'+SLOT_NAME[s]+'<div class="small">'+esc(slotTxt(s))+'</div></div><div class="btn" data-act="pick" data-s="'+s+'">Choisir</div><div class="btn" data-act="autoslot" data-s="'+s+'">Auto</div></div>';
  });
  h+='<div class="sec" style="margin-top:20px">Affichage</div>';
  h+='<div class="card row"><div class="grow">Animation de démarrage Ford</div><div class="toggle'+(store.get('bootAnim',true)?' on':'')+'" data-act="boot"></div></div>';
  h+='<div class="sec" style="margin-top:20px">Système</div>';
  h+='<div class="card row"><div class="grow">Définir cette interface comme écran d’accueil<div class="small">Choisis « Fiesta Dash » puis « Toujours ».</div></div><div class="btn" data-act="home">Ouvrir</div></div>';
  h+='<div class="card row"><div class="grow">Réglages Android</div><div class="btn" data-act="android">Ouvrir</div></div>';
  $('#setList').innerHTML=h;
}
$('#setList').onclick=e=>{
  const b=e.target.closest('[data-act]');if(!b)return;
  const a=b.dataset.act,devs=J(B.obdDevices())||[];
  if(a==='dev'){const d=devs[+b.dataset.i];if(d){store.set('obdAddr',d.address);store.set('obdName',d.name);B.obdConnect(d.address);renderSettings()}}
  else if(a==='disc')B.obdDisconnect();
  else if(a==='refresh'){renderSettings();toast('Liste actualisée')}
  else if(a==='auto'){store.set('autoConnect',!store.get('autoConnect',true));renderSettings()}
  else if(a==='boot'){store.set('bootAnim',!store.get('bootAnim',true));renderSettings()}
  else if(a==='pick'){st.pick=b.dataset.s;show('apps')}
  else if(a==='autoslot'){store.set('slot_'+b.dataset.s,null);store.set('slotname_'+b.dataset.s,null);renderSettings()}
  else if(a==='home')B.openHomeSettings();
  else if(a==='android')B.openSettings();
  else if(a==='bt')B.openBluetoothSettings();
};

/* ===== Navigation entre les vues ===== */
const nav=$$('.nav-btn'),tabs=$$('.tab');
const TAB={home:0,live:1,dtc:2,maint:3,hist:4},NAV={home:0,vehicle:2,settings:3,apps:4};
function show(name){
  st.view=name;
  $$('.view').forEach(v=>v.classList.toggle('show',v.id==='v-'+name));
  tabs.forEach((t,i)=>t.classList.toggle('active',TAB[name]===i));
  nav.forEach((t,i)=>t.classList.toggle('active',NAV[name]===i));
  if(name==='apps')renderApps();else if(name==='dtc')renderDtc();else if(name==='maint')renderMaint();
  else if(name==='hist')renderHist();else if(name==='vehicle')renderVehicle();else if(name==='settings')renderSettings();
}
nav[0].onclick=()=>{st.pick=null;show('home')};
nav[1].onclick=()=>launchSlot('carplay');
nav[2].onclick=()=>show('vehicle');
nav[3].onclick=()=>show('settings');
nav[4].onclick=()=>{st.pick=null;show('apps')};
nav[5].onclick=()=>launchSlot('camera');
['home','live','dtc','maint','hist'].forEach((v,i)=>{tabs[i].onclick=()=>{st.pick=null;show(v)}});
window.onBack=()=>{const m=$('#modal');if(m.classList.contains('show')){m.classList.remove('show');return}if(st.view!=='home'){st.pick=null;show('home')}};
window.onHome=()=>{st.pick=null;show('home')};

$$('.qbtn').forEach(b=>b.onclick=()=>toast('Non disponible : nécessite la lecture du bus CAN Ford'));

/* ===== Rotation 360° locale de la Fiesta =====
   36 vues pré-rendues depuis le GLB : aucun CDN, WebGL ou réseau requis.
   Glisser le doigt horizontalement fait tourner la voiture ; rotation douce au repos. */
(function initCar360(){
  const car=document.getElementById('car');
  if(!car) return;
  const total=36;
  let frame=0, dragging=false, lastX=0, moved=0, lastTime=0;
  const urls=Array.from({length:total},(_,i)=>'car360/'+String(i).padStart(2,'0')+'.png');
  // Précharge et décode toutes les vues avant la rotation pour éviter les flashes.
  const preload=urls.map(u=>new Promise(resolve=>{
    const im=new Image();
    im.decoding='async';
    im.onload=()=>resolve(true);
    im.onerror=()=>resolve(false);
    im.src=u;
  }));
  function setFrame(n){
    frame=(n+total)%total;
    // Les 36 vues locales donnent l'apparence 3D et la rotation tactile.
    // Si une vue manque, index.html bascule automatiquement sur car.png.
    car.src=urls[frame];
  }
  car.addEventListener('pointerdown',e=>{dragging=true;lastX=e.clientX;moved=0;lastTime=Date.now();car.setPointerCapture(e.pointerId);});
  car.addEventListener('pointermove',e=>{
    if(!dragging)return;
    const dx=e.clientX-lastX;lastX=e.clientX;moved+=Math.abs(dx);
    const step=Math.trunc(dx/9);
    if(step!==0)setFrame(frame-step);
  });
  function endDrag(){dragging=false;}
  car.addEventListener('pointerup',endDrag);
  car.addEventListener('pointercancel',endDrag);
  // Rotation régulière, suspendue dès que l'utilisateur touche la voiture.
  // 100 ms par image = environ 10 images/s et un tour complet en 3,6 s.
  Promise.all(preload).then(()=>{
    setInterval(()=>{if(!dragging)setFrame(frame+1);},100);
  });
})();

/* ===== Démarrage ===== */
if(store.get('bootAnim',true)===false){const bt=$('#boot');if(bt)bt.style.display='none'}
updateGauges({});updateConn();updateBadge();
setTimeout(()=>{
  const addr=store.get('obdAddr',null);
  if(!native)B.obdConnect('demo');
  else if(addr&&store.get('autoConnect',true))B.obdConnect(addr);
},1500);
})();
